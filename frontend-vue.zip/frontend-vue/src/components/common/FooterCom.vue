<template>
    <footer class="footer_container">
      <!-- 전체 꼬리말 div 시작 -->
      <div id="footer_box">
        <!-- 꼬리말 로고 시작 -->
        <div id="footer_logo">
          서울쥐
        </div>
        <!-- 꼬리말 로고 끝 -->
  
        <!-- 꼬리말 주소 시작 -->
        <ul id="address">
          <li>서울시 어쩌구 어쩌동 1234 우:123-1234</li>
          <li>TEL:031-123-1234 Email : email@domain.com</li>
          <li>COPYRIGHT (C) 서울쥐 ALL RIGHTS RESERVED</li>
        </ul>
        <!-- 꼬리말 주소 끝 -->
  
      </div>
      <!-- 전체 꼬리말 div 끝 -->
  
    </footer>
  </template>
  
  <script>
  export default {
  
  }
  </script>
  
  <style>
  </style>